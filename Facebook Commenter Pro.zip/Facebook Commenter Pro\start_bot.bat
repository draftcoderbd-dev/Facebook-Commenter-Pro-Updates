@echo off
title FB Reel Commenter Bot
cd /d "%~dp0"

IF NOT EXIST "node_modules\" (
    echo [First Time Setup] Installing required packages...
    echo This might take a few minutes as it downloads the internal browser...
    call npm install
)

echo.
echo Checking for Bot Updates...
call node updater.js
echo.

echo Starting FB Reel Commenter Bot...
npm start
pause
